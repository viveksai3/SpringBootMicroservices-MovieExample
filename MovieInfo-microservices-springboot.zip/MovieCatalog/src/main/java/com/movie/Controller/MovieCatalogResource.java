package com.movie.Controller;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.movie.model.CatalogItem;
import com.movie.model.Movie;
import com.movie.model.Rating;
import com.movie.model.UserRating;

@RestController
@RequestMapping("/catalog")
public class MovieCatalogResource {
	
	@Autowired
	private RestTemplate restTemplate;
	
	
	//same as resttemplate but part of reactive spring (KINDOF)
//	@Autowired
//	private WebClient.Builder webClientBuilder;
	@RequestMapping("/{userId}")
	public List<CatalogItem> getCatalog(@PathVariable("userId") String userId)
	{
		
		UserRating ratings=restTemplate.getForObject("http://ratings-data/ratings/users/"+userId, UserRating.class);

		
		
		
		return ratings.getUserRating().stream().map(r -> {
			Movie movie=restTemplate.getForObject("http://movie-info/movies/"+r.getMovieId(), Movie.class);
			
			
			//using web Client
/*			Movie movie=webClientBuilder.build()
					.get()
					.uri("http://localhost:8083/movies/"+r.getMovieId())
					.retrieve()
					.bodyToMono(Movie.class)
					.block();
			*/
			return new CatalogItem(movie.getName(),"movie",r.getRating());
		})	
		.collect(Collectors.toList());
		
	
		
	}

}
